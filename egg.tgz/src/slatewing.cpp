// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Analyze slatewing lift\n", stdout);
  return lionss_run_workload("slatewing");
}
