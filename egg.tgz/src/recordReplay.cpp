// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Replay recorded trace\n", stdout);
  return lionss_run_workload("recordReplay");
}
