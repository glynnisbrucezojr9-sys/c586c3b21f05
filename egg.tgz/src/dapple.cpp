// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Scatter dapple light"); }
int main(){
  announce();
  return lionss_run_workload("dapple");
}
