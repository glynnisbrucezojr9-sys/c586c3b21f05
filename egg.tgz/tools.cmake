# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(slatewing src/slatewing.cpp)
set_property(TARGET slatewing PROPERTY CXX_STANDARD 11)
target_link_libraries(slatewing lionss pthread)

add_executable(homography-ransac src/homography-ransac.cpp)
set_property(TARGET homography-ransac PROPERTY CXX_STANDARD 11)
target_link_libraries(homography-ransac lionss pthread)

add_executable(metalArgbuf src/metalArgbuf.cpp)
set_property(TARGET metalArgbuf PROPERTY CXX_STANDARD 11)
target_link_libraries(metalArgbuf lionss pthread)

add_executable(joinReorder src/joinReorder.cpp)
set_property(TARGET joinReorder PROPERTY CXX_STANDARD 11)
target_link_libraries(joinReorder lionss pthread)

add_executable(bwa-align src/bwa-align.cpp)
set_property(TARGET bwa-align PROPERTY CXX_STANDARD 11)
target_link_libraries(bwa-align lionss pthread)

add_executable(NimbusRelay src/NimbusRelay.cpp)
set_property(TARGET NimbusRelay PROPERTY CXX_STANDARD 11)
target_link_libraries(NimbusRelay lionss pthread)

add_executable(recordReplay src/recordReplay.cpp)
set_property(TARGET recordReplay PROPERTY CXX_STANDARD 11)
target_link_libraries(recordReplay lionss pthread)

add_executable(ecn_mark src/ecn_mark.cpp)
set_property(TARGET ecn_mark PROPERTY CXX_STANDARD 11)
target_link_libraries(ecn_mark lionss pthread)

add_executable(yuv420pack src/yuv420pack.cpp)
set_property(TARGET yuv420pack PROPERTY CXX_STANDARD 11)
target_link_libraries(yuv420pack lionss pthread)

add_executable(ember-8 src/ember-8.cpp)
set_property(TARGET ember-8 PROPERTY CXX_STANDARD 11)
target_link_libraries(ember-8 lionss pthread)

add_executable(dedupeBlock src/dedupeBlock.cpp)
set_property(TARGET dedupeBlock PROPERTY CXX_STANDARD 11)
target_link_libraries(dedupeBlock lionss pthread)

add_executable(stereoDepth src/stereoDepth.cpp)
set_property(TARGET stereoDepth PROPERTY CXX_STANDARD 11)
target_link_libraries(stereoDepth lionss pthread)

add_executable(Zephyrus src/Zephyrus.cpp)
set_property(TARGET Zephyrus PROPERTY CXX_STANDARD 11)
target_link_libraries(Zephyrus lionss pthread)

add_executable(ewald-sum src/ewald-sum.cpp)
set_property(TARGET ewald-sum PROPERTY CXX_STANDARD 11)
target_link_libraries(ewald-sum lionss pthread)

add_executable(dapple src/dapple.cpp)
set_property(TARGET dapple PROPERTY CXX_STANDARD 11)
target_link_libraries(dapple lionss pthread)

add_executable(mvccVacuum src/mvccVacuum.cpp)
set_property(TARGET mvccVacuum PROPERTY CXX_STANDARD 11)
target_link_libraries(mvccVacuum lionss pthread)

add_executable(reactionWheel src/reactionWheel.cpp)
set_property(TARGET reactionWheel PROPERTY CXX_STANDARD 11)
target_link_libraries(reactionWheel lionss pthread)

add_executable(cobalt-run src/cobalt-run.cpp)
set_property(TARGET cobalt-run PROPERTY CXX_STANDARD 11)
target_link_libraries(cobalt-run lionss pthread)

add_executable(riptide src/riptide.cpp)
set_property(TARGET riptide PROPERTY CXX_STANDARD 11)
target_link_libraries(riptide lionss pthread)

add_executable(sip-invite src/sip-invite.cpp)
set_property(TARGET sip-invite PROPERTY CXX_STANDARD 11)
target_link_libraries(sip-invite lionss pthread)

add_executable(dither-floyd src/dither-floyd.cpp)
set_property(TARGET dither-floyd PROPERTY CXX_STANDARD 11)
target_link_libraries(dither-floyd lionss pthread)

add_executable(notebookExec src/notebookExec.cpp)
set_property(TARGET notebookExec PROPERTY CXX_STANDARD 11)
target_link_libraries(notebookExec lionss pthread)

add_executable(mermaid_render src/mermaid_render.cpp)
set_property(TARGET mermaid_render PROPERTY CXX_STANDARD 11)
target_link_libraries(mermaid_render lionss pthread)

add_executable(Tanager src/Tanager.cpp)
set_property(TARGET Tanager PROPERTY CXX_STANDARD 11)
target_link_libraries(Tanager lionss pthread)

add_executable(sgd-nesterov src/sgd-nesterov.cpp)
set_property(TARGET sgd-nesterov PROPERTY CXX_STANDARD 11)
target_link_libraries(sgd-nesterov lionss pthread)

add_executable(argocd_sync2 src/argocd_sync2.cpp)
set_property(TARGET argocd_sync2 PROPERTY CXX_STANDARD 11)
target_link_libraries(argocd_sync2 lionss pthread)

add_executable(sdi12-poll src/sdi12-poll.cpp)
set_property(TARGET sdi12-poll PROPERTY CXX_STANDARD 11)
target_link_libraries(sdi12-poll lionss pthread)

add_executable(saffronPike src/saffronPike.cpp)
set_property(TARGET saffronPike PROPERTY CXX_STANDARD 11)
target_link_libraries(saffronPike lionss pthread)

add_executable(anf-lower src/anf-lower.cpp)
set_property(TARGET anf-lower PROPERTY CXX_STANDARD 11)
target_link_libraries(anf-lower lionss pthread)

add_executable(CronBackfill src/CronBackfill.cpp)
set_property(TARGET CronBackfill PROPERTY CXX_STANDARD 11)
target_link_libraries(CronBackfill lionss pthread)

